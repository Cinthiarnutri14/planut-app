// src/context/AuthContext.js
import { createContext, useContext, useEffect, useState } from "react";
import { onAuthStateChanged, signInWithPopup, signOut } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, provider, db } from "../firebase";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [authorized, setAuthorized] = useState(false);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Verifica se o e-mail está na coleção "autorizados" no Firestore
        const ref = doc(db, "autorizados", u.email);
        const snap = await getDoc(ref);
        setAuthorized(snap.exists());
      } else {
        setAuthorized(false);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const login = async () => {
    setAuthError("");
    try {
      await signInWithPopup(auth, provider);
    } catch (e) {
      setAuthError("Erro ao fazer login. Tente novamente.");
    }
  };

  const logout = () => signOut(auth);

  return (
    <AuthContext.Provider value={{ user, authorized, loading, login, logout, authError }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
