// src/App.js
import { AuthProvider, useAuth } from "./context/AuthContext";
import LoginPage from "./pages/LoginPage";
import MainApp from "./pages/MainApp";

function AppContent() {
  const { user, authorized, loading } = useAuth();

  if (loading) return (
    <div style={{
      minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
      background:"#0a1628", flexDirection:"column", gap:16
    }}>
      <div style={{
        width:48, height:48, border:"3px solid #1e4d8c", borderTopColor:"#4db8ff",
        borderRadius:"50%", animation:"spin 0.8s linear infinite"
      }}/>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <p style={{color:"#4db8ff", fontFamily:"sans-serif", fontSize:14}}>Carregando PLANUT...</p>
    </div>
  );

  if (!user || !authorized) return <LoginPage />;
  return <MainApp />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
