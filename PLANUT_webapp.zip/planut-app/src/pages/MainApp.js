// src/pages/MainApp.js
import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import TabEstimativas from "../components/TabEstimativas";
import TabTriagem from "../components/TabTriagem";
import TabDiagnostico from "../components/TabDiagnostico";
import TabEnteral from "../components/TabEnteral";
import TabParenteral from "../components/TabParenteral";
import TabEvolucao from "../components/TabEvolucao";
import TabBalanco from "../components/TabBalanco";
import TabPrescricao from "../components/TabPrescricao";

const TABS = [
  { id:"estimativas",  label:"Estimativas",      icon:"📐" },
  { id:"triagem",      label:"Triagem",           icon:"🔍" },
  { id:"diagnostico",  label:"Diagnóstico",       icon:"📋" },
  { id:"enteral",      label:"T.N. Enteral",      icon:"🍼" },
  { id:"parenteral",   label:"T.N. Parenteral",   icon:"💉" },
  { id:"evolucao",     label:"Evolução",          icon:"📊" },
  { id:"balanco",      label:"Balanço Hídrico",   icon:"💧" },
  { id:"prescricao",   label:"Prescrição",        icon:"🏥" },
];

export default function MainApp() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("estimativas");
  const [dados, setDados] = useState({
    // Estimativas
    sexo:"Feminino", raca:"Negro", idade:58, cb:25, aj:51, cp:24,
    kcalKgAgudo:20, ptnKgAgudo:1.2, kcalKgRecup:27, ptnKgRecup:1.5,
    // Triagem
    apacheII:"", sofa:"", comorbidades:"", diasPreUTI:"",
    imc_lt205:"Não", perda_peso:"Não", red_ingestao:"Não", grave_uti:"Sim",
    // Diagnóstico GLIM
    perdaPeso:"", glim_massa:"Ausente", red_ingestao_glim:"Não", doenca_inflam:"Sim",
    etiologia:"",
    // Enteral
    sonda:"Nasogástrica", posicao_sonda:"Gástrico", indicacao_tne:"",
    data_tne:"", tolerancia_tgi:"Boa", formula:"", densidade:1.0,
    vol_prescrito:"", vol_infundido:"", fibras:"Com fibras", osmolaridade:"",
    ptn_formula:"", modulo:"", vrg:"", proicinetico:"Não", jejum:"Não",
    // Parenteral
    indicacao_tnp:"", tipo_np:"NPT – Central", acesso_venoso:"CVC – Subclávia",
    cateter:"", data_tnp:"", glicose:"", aminoacidos:"", lipidios:"",
    emulsao:"", eletrolitos:"", vitaminas:"", vol_tnp:"", glicemia:"",
    triglicerideos:"", fosforo:"", potassio:"", sodio:"", magnesio:"",
    // Evolução (7 dias)
    evolucao: Array(7).fill(null).map((_,i)=>({
      dia:i+1, data:"", peso:"", cb:"", cp:"", glicemia:"",
      kcal:"", ptn:"", vrg:"", bh:"", via:"", tolerancia:"", jejum:"", pcr:"", albumina:""
    })),
    // Balanço
    ganhos: {
      enteral:["","","",""], parenteral:["","","",""], sf:["","","",""],
      sg:["","","",""], ringer:["","","",""], albumina_hemo:["","","",""],
      medicamentos:["","","",""], vo:["","","",""], outros:["","","",""]
    },
    perdas: {
      diurese:["","","",""], drenos:["","","",""], sng:["","","",""],
      fezes:["","","",""], vomitos:["","","",""], sangramento:["","","",""],
      outros_p:["","","",""]
    },
    hist_balanco: Array(7).fill(null).map((_,i)=>({
      dia:i+1, data:"", ganhos:"", perdas:"", balanco:"", diurese:"", peso:""
    })),
    // Prescrição
    paciente:"", cro:"", via_tn:"", formula_prescrita:"", vol_dia:"", vel_hora:"", obs:""
  });

  const set = (key, val) => setDados(prev => ({...prev, [key]: val}));

  // Cálculos centralizados (usados em múltiplas abas)
  const calc = (() => {
    const d = dados;
    // Peso estimado Chumlea
    let peso = "";
    const i = Number(d.idade), cb = Number(d.cb), aj = Number(d.aj), cp = Number(d.cp);
    if (d.sexo==="Feminino" && d.raca==="Negro" && i>=19 && i<=59) peso = +(0.98*cb+1.27*cp+0.4*aj-0.98*i+77.56).toFixed(1);
    else if (d.sexo==="Feminino" && d.raca==="Negro" && i>=60 && i<=80) peso = +(1.24*cb+1.21*cp+0.33*aj-0.99*i+57.74).toFixed(1);
    else if (d.sexo==="Feminino" && d.raca==="Branco" && i>=19 && i<=59) peso = +(1.01*cb+2.81*cp+0.33*aj-0.99*i+77.56).toFixed(1);
    else if (d.sexo==="Feminino" && d.raca==="Branco" && i>=60 && i<=80) peso = +(1.01*cb+2.81*cp+0.33*aj-0.99*i+77.56).toFixed(1);
    else if (d.sexo==="Masculino" && d.raca==="Negro" && i>=19 && i<=59) peso = +(0.98*cb+1.27*cp+0.4*aj-0.98*i+77.56).toFixed(1);
    else if (d.sexo==="Masculino" && d.raca==="Negro" && i>=60 && i<=80) peso = +(1.27*cb+0.87*cp+0.98*aj-0.37*i+41.46).toFixed(1);
    else if (d.sexo==="Masculino" && d.raca==="Branco" && i>=19 && i<=59) peso = +(1.19*cb+1.21*cp+1.15*aj-1.16*i+59.72).toFixed(1);
    else if (d.sexo==="Masculino" && d.raca==="Branco" && i>=60 && i<=80) peso = +(1.10*cb+1.10*cp+0.73*aj-0.09*i+20.05).toFixed(1);

    const alt = d.sexo==="Feminino"
      ? +((2.47*aj - 0.87*i + 84.88)/100).toFixed(2)
      : +((1.83*aj - 0.24*i + 84.88)/100).toFixed(2);
    const imc = peso && alt ? +(peso/(alt*alt)).toFixed(1) : "";
    const piAdulto = d.sexo==="Feminino" ? +(21.75*alt*alt).toFixed(0) : +(22.5*alt*alt).toFixed(0);
    const piIdoso = +(23.5*alt*alt).toFixed(0);
    const classCP = d.cp ? (d.sexo==="Feminino" ? (Number(d.cp)<=33?"⚠️ Abaixo do ideal":"✅ Adequado") : (Number(d.cp)<=34?"⚠️ Abaixo do ideal":"✅ Adequado")) : "—";

    const kcalAgudo = peso ? +(peso * Number(d.kcalKgAgudo)).toFixed(0) : "";
    const ptnAgudo  = peso ? +(peso * Number(d.ptnKgAgudo)).toFixed(1) : "";
    const kcalRecup = peso ? +(peso * Number(d.kcalKgRecup)).toFixed(0) : "";
    const ptnRecup  = peso ? +(peso * Number(d.ptnKgRecup)).toFixed(1) : "";

    // NUTRIC
    const idade_n = i<50?0:i<=74?1:2;
    const apache_n = d.apacheII===""?"":Number(d.apacheII)<15?0:Number(d.apacheII)<=19?1:Number(d.apacheII)<=27?2:3;
    const sofa_n = d.sofa===""?"":Number(d.sofa)<6?0:Number(d.sofa)<=9?1:2;
    const comor_n = d.comorbidades===""?"":Number(d.comorbidades)<=1?0:1;
    const dias_n = d.diasPreUTI===""?"":Number(d.diasPreUTI)===0?0:1;
    const nutric_total = [idade_n,apache_n,sofa_n,comor_n,dias_n].every(x=>x!=="")?
      [idade_n,apache_n,sofa_n,comor_n,dias_n].reduce((a,b)=>a+b,0) : "";

    // NRS
    const nrs_imc = d.imc_lt205==="Sim"?1:0;
    const nrs_pp = d.perda_peso==="Sim"?1:0;
    const nrs_ri = d.red_ingestao==="Sim"?1:0;
    const nrs_uti = d.grave_uti==="Sim"?1:0;
    const nrs_idade = i>=70?1:0;
    const nrs_total = nrs_imc+nrs_pp+nrs_ri+nrs_uti+nrs_idade;

    // GLIM
    const pp_num = Number(d.perdaPeso)||0;
    const glim_peso = pp_num>10?"grave":pp_num>=5?"moderado":"nao";
    const glim_imc_result = imc ? (i<70?(imc<18.5?"grave":imc<20?"moderado":"nao"):(imc<20?"grave":imc<22?"moderado":"nao")) : "nao";
    const glim_massa_r = d.glim_massa==="Grave"?"grave":d.glim_massa==="Leve/Moderada"?"moderado":"nao";
    const fenot_grave = [glim_peso,glim_imc_result,glim_massa_r].some(x=>x==="grave");
    const fenot_mod = !fenot_grave && [glim_peso,glim_imc_result,glim_massa_r].some(x=>x==="moderado");
    const etiol_pos = d.red_ingestao_glim==="Sim"||d.doenca_inflam==="Sim";
    const glim_dx = (fenot_grave||fenot_mod)&&etiol_pos ? (fenot_grave?"Estágio 2 – DESNUTRIÇÃO GRAVE":"Estágio 1 – DESNUTRIÇÃO MODERADA") : "Sem diagnóstico de desnutrição";

    // Adequação enteral
    const kcal_ofert = dados.vol_prescrito && dados.densidade ? +(Number(dados.vol_prescrito)*Number(dados.densidade)).toFixed(0) : "";
    const adeq_kcal = kcal_ofert && kcalAgudo ? +(kcal_ofert/kcalAgudo*100).toFixed(1) : "";
    const ptn_ofert = dados.vol_prescrito && dados.ptn_formula ? +(Number(dados.vol_prescrito)*(Number(dados.ptn_formula)/1000)).toFixed(1) : "";
    const adeq_ptn = ptn_ofert && ptnAgudo ? +(ptn_ofert/ptnAgudo*100).toFixed(1) : "";

    return { peso, alt, imc, piAdulto, piIdoso, classCP,
             kcalAgudo, ptnAgudo, kcalRecup, ptnRecup,
             nutric_total, nrs_total, nrs_idade,
             glim_dx, fenot_grave, fenot_mod, etiol_pos,
             kcal_ofert, adeq_kcal, ptn_ofert, adeq_ptn };
  })();

  const tabComponents = {
    estimativas: <TabEstimativas dados={dados} set={set} calc={calc} />,
    triagem:     <TabTriagem dados={dados} set={set} calc={calc} />,
    diagnostico: <TabDiagnostico dados={dados} set={set} calc={calc} />,
    enteral:     <TabEnteral dados={dados} set={set} calc={calc} />,
    parenteral:  <TabParenteral dados={dados} set={set} calc={calc} />,
    evolucao:    <TabEvolucao dados={dados} set={set} calc={calc} />,
    balanco:     <TabBalanco dados={dados} set={set} calc={calc} />,
    prescricao:  <TabPrescricao dados={dados} set={set} calc={calc} />,
  };

  return (
    <div style={{ minHeight:"100vh", background:"#060f20", fontFamily:"'Segoe UI',system-ui,sans-serif" }}>
      <style>{`
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#0a1628}
        ::-webkit-scrollbar-thumb{background:#1e4d8c;border-radius:3px}
        .tab-btn { background:none; border:none; cursor:pointer; padding:10px 16px;
          border-radius:10px; font-size:13px; font-weight:600; transition:all 0.2s;
          white-space:nowrap; display:flex; align-items:center; gap:6px; color:rgba(255,255,255,0.45); }
        .tab-btn:hover { background:rgba(255,255,255,0.06); color:rgba(255,255,255,0.8); }
        .tab-btn.active { background:rgba(26,86,219,0.25); color:#4db8ff;
          box-shadow:0 0 0 1px rgba(77,184,255,0.2); }
        input, select, textarea {
          background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1);
          color:#fff; border-radius:8px; padding:8px 12px; font-size:13px;
          font-family:inherit; transition:border-color 0.2s; outline:none; width:100%; box-sizing:border-box;
        }
        input:focus, select:focus, textarea:focus { border-color:#4db8ff; background:rgba(77,184,255,0.08); }
        select option { background:#0a1628; color:#fff; }
        label { color:rgba(255,255,255,0.55); font-size:12px; font-weight:600;
          letter-spacing:0.5px; text-transform:uppercase; display:block; margin-bottom:4px; }
        .result-box { background:rgba(77,184,255,0.08); border:1px solid rgba(77,184,255,0.2);
          border-radius:10px; padding:10px 14px; color:#4db8ff; font-weight:700; font-size:14px;
          text-align:center; }
        .warn-box { background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2);
          border-radius:10px; padding:10px 14px; color:#fca5a5; font-size:13px; }
        .ok-box { background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.2);
          border-radius:10px; padding:10px 14px; color:#6ee7b7; font-size:13px; }
        .section-title { font-size:11px; font-weight:700; letter-spacing:1.5px;
          text-transform:uppercase; color:rgba(255,255,255,0.3); margin:20px 0 12px;
          padding-bottom:6px; border-bottom:1px solid rgba(255,255,255,0.06); }
        .grid2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        .grid3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
        .grid4 { display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:10px; }
        @media(max-width:640px) { .grid2,.grid3,.grid4{grid-template-columns:1fr 1fr} }
        @media(max-width:420px) { .grid2,.grid3,.grid4{grid-template-columns:1fr} }
        .badge { display:inline-block; padding:3px 10px; border-radius:99px; font-size:11px; font-weight:700; }
        .badge-blue { background:rgba(77,184,255,0.15); color:#4db8ff; }
        .badge-green { background:rgba(16,185,129,0.15); color:#6ee7b7; }
        .badge-red { background:rgba(239,68,68,0.15); color:#fca5a5; }
        .badge-yellow { background:rgba(251,191,36,0.15); color:#fcd34d; }
        @media print { .no-print{display:none!important} }
      `}</style>

      {/* Header */}
      <div className="no-print" style={{
        background:"rgba(255,255,255,0.03)", borderBottom:"1px solid rgba(255,255,255,0.07)",
        padding:"12px 20px", display:"flex", alignItems:"center", justifyContent:"space-between",
        position:"sticky", top:0, zIndex:100, backdropFilter:"blur(10px)"
      }}>
        <div style={{display:"flex", alignItems:"center", gap:10}}>
          <span style={{fontSize:22}}>🏥</span>
          <div>
            <div style={{color:"#fff", fontWeight:800, fontSize:16, lineHeight:1}}>PLANUT</div>
            <div style={{color:"rgba(255,255,255,0.35)", fontSize:10, letterSpacing:1}}>NUTRIÇÃO HOSPITALAR · UTI</div>
          </div>
        </div>
        <div style={{display:"flex", alignItems:"center", gap:12}}>
          {calc.peso && (
            <div style={{
              background:"rgba(77,184,255,0.1)", border:"1px solid rgba(77,184,255,0.2)",
              borderRadius:8, padding:"4px 12px", fontSize:12, color:"#4db8ff"
            }}>
              Peso: <strong>{calc.peso} kg</strong> · IMC: <strong>{calc.imc}</strong>
            </div>
          )}
          <div style={{textAlign:"right"}}>
            <div style={{color:"rgba(255,255,255,0.6)", fontSize:12}}>{user?.displayName}</div>
            <div style={{color:"rgba(255,255,255,0.3)", fontSize:10}}>{user?.email}</div>
          </div>
          <button onClick={logout} style={{
            background:"rgba(239,68,68,0.15)", border:"1px solid rgba(239,68,68,0.2)",
            color:"#fca5a5", borderRadius:8, padding:"6px 14px", cursor:"pointer",
            fontSize:12, fontWeight:600
          }}>Sair</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="no-print" style={{
        display:"flex", gap:4, padding:"12px 20px", overflowX:"auto",
        borderBottom:"1px solid rgba(255,255,255,0.06)",
        background:"rgba(255,255,255,0.02)"
      }}>
        {TABS.map(t=>(
          <button key={t.id} className={`tab-btn ${activeTab===t.id?"active":""}`}
            onClick={()=>setActiveTab(t.id)}>
            <span>{t.icon}</span> {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding:"24px 20px", maxWidth:1100, margin:"0 auto" }}>
        {tabComponents[activeTab]}
      </div>
    </div>
  );
}
