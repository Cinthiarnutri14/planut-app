// src/pages/LoginPage.js
import { useAuth } from "../context/AuthContext";

export default function LoginPage() {
  const { user, authorized, login, authError } = useAuth();

  const notAuthorized = user && !authorized;

  return (
    <div style={{
      minHeight:"100vh", background:"#040d1a",
      display:"flex", alignItems:"center", justifyContent:"center",
      fontFamily:"'Segoe UI', system-ui, sans-serif",
      position:"relative", overflow:"hidden"
    }}>
      {/* Fundo animado */}
      <style>{`
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-18px)} }
        @keyframes pulse { 0%,100%{opacity:0.15} 50%{opacity:0.35} }
        @keyframes fadein { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
        @keyframes shimmer { 0%{background-position:200% center} 100%{background-position:-200% center} }
        .btn-google {
          display:flex; align-items:center; gap:14px; padding:16px 32px;
          background:linear-gradient(135deg,#1a56db,#0e3a8a);
          color:#fff; border:none; border-radius:14px; cursor:pointer;
          font-size:16px; font-weight:600; letter-spacing:0.3px;
          box-shadow:0 4px 24px rgba(26,86,219,0.4);
          transition:all 0.2s; width:100%;
          justify-content:center;
        }
        .btn-google:hover { transform:translateY(-2px); box-shadow:0 8px 32px rgba(26,86,219,0.6); }
        .btn-google:active { transform:translateY(0); }
        .card { animation: fadein 0.7s ease both; }
        .tag {
          display:inline-block; padding:4px 12px; border-radius:99px;
          background:rgba(77,184,255,0.12); color:#4db8ff;
          font-size:11px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase;
          border:1px solid rgba(77,184,255,0.2); margin-bottom:20px;
        }
        .divider { display:flex; align-items:center; gap:12px; margin:20px 0; }
        .divider span { flex:1; height:1px; background:rgba(255,255,255,0.08); }
        .divider p { color:rgba(255,255,255,0.3); font-size:12px; }
      `}</style>

      {/* Círculos de fundo */}
      {[
        {w:500,h:500,top:"-15%",left:"-10%",color:"rgba(26,86,219,0.12)"},
        {w:400,h:400,bottom:"-10%",right:"-5%",color:"rgba(77,184,255,0.08)"},
        {w:200,h:200,top:"40%",right:"15%",color:"rgba(16,185,129,0.07)"},
      ].map((c,i)=>(
        <div key={i} style={{
          position:"absolute", width:c.w, height:c.h, borderRadius:"50%",
          background:c.color, top:c.top, left:c.left, bottom:c.bottom, right:c.right,
          filter:"blur(60px)", animation:`pulse ${3+i}s ease-in-out infinite`,
          animationDelay:`${i*0.8}s`
        }}/>
      ))}

      {/* Card */}
      <div className="card" style={{
        background:"rgba(255,255,255,0.04)", backdropFilter:"blur(20px)",
        border:"1px solid rgba(255,255,255,0.08)", borderRadius:24,
        padding:"48px 40px", width:"100%", maxWidth:420,
        boxShadow:"0 24px 80px rgba(0,0,0,0.5)", position:"relative", zIndex:1
      }}>
        {/* Logo / Ícone */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{
            width:72, height:72, borderRadius:20,
            background:"linear-gradient(135deg,#1a56db,#4db8ff)",
            display:"inline-flex", alignItems:"center", justifyContent:"center",
            fontSize:32, marginBottom:16, boxShadow:"0 8px 32px rgba(26,86,219,0.4)",
            animation:"float 3s ease-in-out infinite"
          }}>🏥</div>
          <div className="tag">Acesso exclusivo</div>
          <h1 style={{
            margin:"0 0 8px", fontSize:28, fontWeight:800, color:"#fff",
            background:"linear-gradient(135deg,#fff,#a8c8ff)",
            WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent"
          }}>PLANUT</h1>
          <p style={{ margin:0, color:"rgba(255,255,255,0.45)", fontSize:14, lineHeight:1.6 }}>
            Planejamento Nutricional Hospitalar<br/>
            <span style={{color:"rgba(255,255,255,0.25)"}}>UTI · Terapia Enteral · Parenteral</span>
          </p>
        </div>

        <div className="divider">
          <span/><p>Acesse com sua conta Google</p><span/>
        </div>

        {notAuthorized ? (
          /* Acesso não autorizado */
          <div style={{
            background:"rgba(239,68,68,0.1)", border:"1px solid rgba(239,68,68,0.2)",
            borderRadius:12, padding:20, textAlign:"center", marginBottom:16
          }}>
            <div style={{fontSize:28, marginBottom:10}}>🔒</div>
            <p style={{color:"#fca5a5", fontSize:14, margin:"0 0 8px", fontWeight:600}}>
              Acesso não autorizado
            </p>
            <p style={{color:"rgba(255,255,255,0.4)", fontSize:13, margin:0, lineHeight:1.6}}>
              O e-mail <strong style={{color:"#fca5a5"}}>{user?.email}</strong> não possui uma licença ativa.<br/>
              Adquira o PLANUT no Hotmart para liberar o acesso.
            </p>
            <a href="https://hotmart.com" target="_blank" rel="noreferrer" style={{
              display:"inline-block", marginTop:14, padding:"10px 24px",
              background:"linear-gradient(135deg,#f97316,#ea580c)",
              color:"#fff", borderRadius:10, textDecoration:"none",
              fontSize:13, fontWeight:700, boxShadow:"0 4px 16px rgba(249,115,22,0.4)"
            }}>
              🛒 Adquirir no Hotmart
            </a>
          </div>
        ) : (
          <button className="btn-google" onClick={login}>
            <svg width="20" height="20" viewBox="0 0 48 48">
              <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
              <path fill="#FF3D00" d="m6.306 14.691 6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/>
              <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
              <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
            </svg>
            Entrar com Google
          </button>
        )}

        {authError && (
          <p style={{color:"#fca5a5", fontSize:13, textAlign:"center", marginTop:12}}>{authError}</p>
        )}

        <p style={{
          color:"rgba(255,255,255,0.2)", fontSize:11, textAlign:"center",
          marginTop:24, marginBottom:0, lineHeight:1.6
        }}>
          Ao acessar você concorda com os termos de uso.<br/>
          Acesso individual e intransferível. © PLANUT {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
