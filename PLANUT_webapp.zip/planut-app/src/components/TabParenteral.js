// src/components/TabParenteral.js
const SEL=({label,val,onChange,opts})=>(<div><label>{label}</label><select value={val} onChange={e=>onChange(e.target.value)}>{opts.map(o=><option key={o}>{o}</option>)}</select></div>);
const NUM=({label,val,onChange,step,unit})=>(<div><label>{label}{unit&&<span style={{color:"rgba(255,255,255,0.3)",marginLeft:4,fontWeight:400,textTransform:"none"}}>{unit}</span>}</label><input type="number" min="0" step={step||1} value={val} onChange={e=>onChange(e.target.value)}/></div>);
const TXT=({label,val,onChange,placeholder})=>(<div><label>{label}</label><input type="text" value={val} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/></div>);

function LabRow({label,val,onChange,meta,classify}) {
  const cl = val!==""&&classify ? classify(Number(val)) : null;
  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,alignItems:"end"}}>
      <NUM label={label} val={val} onChange={onChange} step="0.1"/>
      <div style={{paddingBottom:2}}>
        <label>Meta</label>
        <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,paddingTop:6}}>{meta}</div>
      </div>
      <div style={{paddingBottom:2}}>
        <label>Resultado</label>
        <div style={{
          background:cl?.ok?"rgba(16,185,129,0.1)":"rgba(239,68,68,0.1)",
          border:`1px solid ${cl?.ok?"rgba(16,185,129,0.2)":"rgba(239,68,68,0.2)"}`,
          borderRadius:8,padding:"6px 10px",fontSize:12,fontWeight:600,
          color:cl?.ok?"#6ee7b7":"#fca5a5"
        }}>{cl?.label||"—"}</div>
      </div>
    </div>
  );
}

export default function TabParenteral({dados:d,set,calc:c}) {
  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>💉</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Terapia Nutricional Parenteral</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>TNP / NPT · BRASPEN 2023 · ASPEN/SCCM 2022</p>
        </div>
      </div>

      <div className="grid2">
        <div>
          <div className="section-title">Indicação e Via</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SEL label="Indicação TNP" val={d.indicacao_tnp} onChange={v=>set("indicacao_tnp",v)} opts={["TGI não funcional","TNE contraindicada","NP Suplementar (NPS)","NP Total (NPT)"]}/>
            <SEL label="Tipo de NP" val={d.tipo_np} onChange={v=>set("tipo_np",v)} opts={["NPT – Central","NP Periférica","NPS – Suplementar"]}/>
            <SEL label="Acesso venoso" val={d.acesso_venoso} onChange={v=>set("acesso_venoso",v)} opts={["CVC – Subclávia","CVC – Jugular","CVC – Femoral","PICC","Veia periférica"]}/>
            <TXT label="Cateter / Identificação" val={d.cateter} onChange={v=>set("cateter",v)}/>
            <TXT label="Data início TNP" val={d.data_tnp} onChange={v=>set("data_tnp",v)} placeholder="DD/MM/AAAA"/>
          </div>
        </div>
        <div>
          <div className="section-title">Composição da Solução</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <NUM label="Glicose" val={d.glicose} onChange={v=>set("glicose",v)} unit="g/dia"/>
            <NUM label="Aminoácidos" val={d.aminoacidos} onChange={v=>set("aminoacidos",v)} unit="g/dia"/>
            <NUM label="Lipídios" val={d.lipidios} onChange={v=>set("lipidios",v)} unit="g/dia"/>
            <SEL label="Emulsão lipídica" val={d.emulsao} onChange={v=>set("emulsao",v)} opts={["SMOF (soja+MCT+oliva+peixe)","MCT/LCT","Óleo de oliva","NÃO usar exclusivo soja"]}/>
            <NUM label="Volume total" val={d.vol_tnp} onChange={v=>set("vol_tnp",v)} unit="ml/dia"/>
          </div>
        </div>
      </div>

      <div className="section-title">Monitoramento Laboratorial</div>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        <LabRow label="Glicemia (mg/dL)" val={d.glicemia} onChange={v=>set("glicemia",v)} meta="140-180 mg/dL"
          classify={v=>({ok:v>=140&&v<=180,label:v>=140&&v<=180?"✅ Na meta":v<140?"⚠️ Hipoglicemia":"⚠️ Hiperglicemia"})}/>
        <LabRow label="Triglicerídeos (mg/dL)" val={d.triglicerideos} onChange={v=>set("triglicerideos",v)} meta="< 400 mg/dL"
          classify={v=>({ok:v<400,label:v<400?"✅ OK":"⚠️ Suspender lipídios"})}/>
        <LabRow label="Fósforo (mEq/L)" val={d.fosforo} onChange={v=>set("fosforo",v)} meta="≥ 2,5"
          classify={v=>({ok:v>=2.5,label:v>=2.5?"✅ Normal":"🔴 Risco S. Realimentação"})}/>
        <LabRow label="Potássio (mEq/L)" val={d.potassio} onChange={v=>set("potassio",v)} meta="3,5-5,0"
          classify={v=>({ok:v>=3.5&&v<=5,label:v>=3.5&&v<=5?"✅ Normal":v<3.5?"⚠️ Hipocalemia":"⚠️ Hipercalemia"})}/>
        <LabRow label="Sódio (mEq/L)" val={d.sodio} onChange={v=>set("sodio",v)} meta="135-145"
          classify={v=>({ok:v>=135&&v<=145,label:v>=135&&v<=145?"✅ Normal":"⚠️ Avaliar"})}/>
        <LabRow label="Magnésio (mg/dL)" val={d.magnesio} onChange={v=>set("magnesio",v)} meta="1,8-2,4"
          classify={v=>({ok:v>=1.8&&v<=2.4,label:v>=1.8&&v<=2.4?"✅ Normal":"⚠️ Avaliar"})}/>
      </div>

      <div style={{marginTop:16,background:"rgba(251,191,36,0.08)",border:"1px solid rgba(251,191,36,0.2)",borderRadius:12,padding:14}}>
        <p style={{color:"#fcd34d",fontSize:12,margin:0,lineHeight:1.7}}>
          ⚠️ <strong>BRASPEN 2023:</strong> NPS somente após 7-10 dias | Glicemia alvo 140-180 mg/dL | Não usar EL exclusiva de soja | Glutamina IV contraindicada em disfunção orgânica múltipla | Monitorar síndrome de realimentação (↓P, K, Mg)
        </p>
      </div>
    </div>
  );
}
