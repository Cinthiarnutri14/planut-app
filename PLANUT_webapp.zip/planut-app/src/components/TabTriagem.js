// src/components/TabTriagem.js
const SEL=({label,val,onChange,opts})=>(<div><label>{label}</label><select value={val} onChange={e=>onChange(e.target.value)}>{opts.map(o=><option key={o}>{o}</option>)}</select></div>);
const NUM=({label,val,onChange,step})=>(<div><label>{label}</label><input type="number" min="0" step={step||1} value={val} onChange={e=>onChange(e.target.value)}/></div>);

function ScoreCard({title,score,max,classification,color,ref_}) {
  const pct = score!==""&&max ? (score/max)*100 : 0;
  return (
    <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:14,padding:20}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div style={{color:"#fff",fontWeight:700,fontSize:15}}>{title}</div>
        <div style={{textAlign:"right"}}>
          <div style={{color:color||"#4db8ff",fontSize:28,fontWeight:900,lineHeight:1}}>{score!==""?score:"—"}</div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>de {max} pts</div>
        </div>
      </div>
      {score!==""&&<div style={{height:6,background:"rgba(255,255,255,0.06)",borderRadius:3,marginBottom:10}}>
        <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:color||"#4db8ff",borderRadius:3,transition:"width 0.4s"}}/>
      </div>}
      <div style={{background:color?`rgba(${color==="rgb(239,68,68)"?"239,68,68":"77,184,255"},0.1)`:"rgba(77,184,255,0.08)",
        borderRadius:8,padding:"8px 12px",fontSize:12,color:color||"#4db8ff",fontWeight:600}}>
        {classification||"Preencha os campos acima"}
      </div>
      {ref_&&<p style={{color:"rgba(255,255,255,0.25)",fontSize:10,margin:"8px 0 0"}}>{ref_}</p>}
    </div>
  );
}

export default function TabTriagem({dados:d,set,calc:c}) {
  const nutricColor = c.nutric_total>=5?"#ef4444":c.nutric_total>=3?"#fbbf24":"#10b981";
  const nutricClass = c.nutric_total!==""?(c.nutric_total>=5?"🔴 ALTO RISCO – Intervenção imediata":(c.nutric_total>=3?"🟡 RISCO MODERADO":"🟢 BAIXO RISCO – Monitorar")):"";
  const nrsColor = c.nrs_total>=3?"#ef4444":c.nrs_total>=1?"#fbbf24":"#10b981";
  const nrsClass = c.nrs_total>=3?"🔴 RISCO NUTRICIONAL – Iniciar plano nutricional":c.nrs_total>=1?"🟡 RISCO MODERADO – Reavaliar em 1 semana":"🟢 SEM RISCO – Triagem semanal";

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>🔍</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Triagem Nutricional</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>NUTRIC Score + NRS-2002 · BRASPEN 2023</p>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
        {/* NUTRIC */}
        <div>
          <div className="section-title">NUTRIC Score Modificado (sem IL-6)</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <div style={{background:"rgba(255,255,255,0.03)",borderRadius:10,padding:12,border:"1px solid rgba(255,255,255,0.07)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:"rgba(255,255,255,0.6)",fontSize:13}}>Idade</span>
                <span style={{color:"#4db8ff",fontWeight:700}}>{d.idade} anos → {d.idade<50?0:d.idade<=74?1:2} pts</span>
              </div>
              <div style={{color:"rgba(255,255,255,0.25)",fontSize:11,marginTop:2}}>{"<50=0 | 50-74=1 | ≥75=2"}</div>
            </div>
            <NUM label="APACHE II" val={d.apacheII} onChange={v=>set("apacheII",v)}/>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:-6}}>{"<15=0 | 15-19=1 | 20-27=2 | ≥28=3 pts"}</div>
            <NUM label="SOFA" val={d.sofa} onChange={v=>set("sofa",v)}/>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:-6}}>{"<6=0 | 6-9=1 | ≥10=2 pts"}</div>
            <NUM label="Nº de comorbidades" val={d.comorbidades} onChange={v=>set("comorbidades",v)}/>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:-6}}>{"0-1=0 | ≥2=1 pt"}</div>
            <NUM label="Dias internação pré-UTI" val={d.diasPreUTI} onChange={v=>set("diasPreUTI",v)}/>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:-6}}>{"0 dias=0 | ≥1=1 pt"}</div>
          </div>
          <div style={{marginTop:12}}>
            <ScoreCard title="NUTRIC Total" score={c.nutric_total} max={9} classification={nutricClass} color={nutricColor} ref_="Heyland et al. 2011 | Alto risco: ≥5 pts"/>
          </div>
        </div>

        {/* NRS-2002 */}
        <div>
          <div className="section-title">NRS-2002</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SEL label="IMC < 20,5 kg/m²?" val={d.imc_lt205} onChange={v=>set("imc_lt205",v)} opts={["Não","Sim"]}/>
            <SEL label="Perda de peso nos últimos 3 meses?" val={d.perda_peso} onChange={v=>set("perda_peso",v)} opts={["Não","Sim"]}/>
            <SEL label="Redução ingestão alimentar na última semana?" val={d.red_ingestao} onChange={v=>set("red_ingestao",v)} opts={["Não","Sim"]}/>
            <SEL label="Paciente gravemente enfermo (UTI)?" val={d.grave_uti} onChange={v=>set("grave_uti",v)} opts={["Sim","Não"]}/>
            <div style={{background:"rgba(77,184,255,0.08)",border:"1px solid rgba(77,184,255,0.2)",borderRadius:10,padding:12}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:"rgba(255,255,255,0.6)",fontSize:13}}>Idade ≥ 70 anos?</span>
                <span style={{color:"#4db8ff",fontWeight:700,fontSize:13}}>
                  {Number(d.idade)>=70?"✅ Sim – +1 pt automático":"Não – 0 pt"}
                </span>
              </div>
              <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:4}}>Calculado automaticamente da aba Estimativas</div>
            </div>
          </div>
          <div style={{marginTop:12}}>
            <ScoreCard title="NRS-2002 Total" score={c.nrs_total} max={5} classification={nrsClass} color={nrsColor} ref_="Kondrup et al. 2003 | Risco: ≥3 pts"/>
          </div>
        </div>
      </div>

      <div style={{marginTop:16,background:"rgba(251,191,36,0.08)",border:"1px solid rgba(251,191,36,0.2)",borderRadius:12,padding:14}}>
        <p style={{color:"#fcd34d",fontSize:12,margin:0,lineHeight:1.7}}>
          ⚠️ <strong>BRASPEN 2023:</strong> Triagem em até 48h da admissão na UTI · Alto risco → avaliação nutricional completa + intervenção precoce (24-48h) · Reavaliação a cada 7-10 dias
        </p>
      </div>
    </div>
  );
}
