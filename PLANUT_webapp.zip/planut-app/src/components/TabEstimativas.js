// src/components/TabEstimativas.js
const SEL = ({label,id,val,onChange,opts}) => (
  <div><label>{label}</label>
    <select value={val} onChange={e=>onChange(e.target.value)}>
      {opts.map(o=><option key={o}>{o}</option>)}
    </select>
  </div>
);
const NUM = ({label,val,onChange,min,step,unit}) => (
  <div><label>{label}{unit&&<span style={{color:"rgba(255,255,255,0.3)",marginLeft:4,fontWeight:400,textTransform:"none"}}>{unit}</span>}</label>
    <input type="number" min={min||0} step={step||1} value={val} onChange={e=>onChange(e.target.value)}/>
  </div>
);
const Res = ({label,val,unit,color}) => (
  <div style={{background:color||"rgba(77,184,255,0.08)",border:"1px solid rgba(77,184,255,0.2)",
    borderRadius:10,padding:"10px 14px"}}>
    <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:2}}>{label}</div>
    <div style={{color:color?"#6ee7b7":"#4db8ff",fontWeight:800,fontSize:18}}>{val||"—"} <span style={{fontSize:12,fontWeight:400}}>{unit}</span></div>
  </div>
);

export default function TabEstimativas({dados:d, set, calc:c}) {
  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>📐</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Estimativas Antropométricas</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>Chumlea et al. 1988 · BRASPEN 2021</p>
        </div>
      </div>

      <div className="section-title">Dados do Paciente</div>
      <div className="grid3">
        <SEL label="Sexo" val={d.sexo} onChange={v=>set("sexo",v)} opts={["Feminino","Masculino"]}/>
        <SEL label="Cor / Raça" val={d.raca} onChange={v=>set("raca",v)} opts={["Negro","Branco"]}/>
        <NUM label="Idade" val={d.idade} onChange={v=>set("idade",v)} unit="anos"/>
        <NUM label="CB – Circ. Braço" val={d.cb} onChange={v=>set("cb",v)} unit="cm"/>
        <NUM label="AJ – Altura Joelho" val={d.aj} onChange={v=>set("aj",v)} unit="cm" step="0.1"/>
        <NUM label="CP – Circ. Panturrilha" val={d.cp} onChange={v=>set("cp",v)} unit="cm" step="0.1"/>
      </div>

      <div className="section-title">Resultados – Calculados Automaticamente</div>
      <div className="grid3">
        <Res label="Peso Estimado" val={c.peso} unit="kg"/>
        <Res label="Altura Estimada" val={c.alt} unit="m"/>
        <Res label="IMC" val={c.imc} unit="kg/m²"/>
        <Res label="Peso Ideal Adulto" val={c.piAdulto} unit="kg"/>
        <Res label="Peso Ideal Idoso/a" val={c.piIdoso} unit="kg"/>
        <Res label="Classif. Panturrilha" val={c.classCP} color={c.classCP?.includes("⚠️")?"rgba(239,68,68,0.1)":undefined}/>
      </div>

      <div className="section-title">Necessidade Energética e Proteica</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
        <div style={{background:"rgba(255,255,255,0.03)",borderRadius:14,padding:16,border:"1px solid rgba(255,255,255,0.07)"}}>
          <div style={{color:"#4db8ff",fontWeight:700,fontSize:13,marginBottom:12}}>⚡ Fase Aguda (≤4° dia)</div>
          <div className="grid2" style={{marginBottom:10}}>
            <NUM label="Kcal/kg" val={d.kcalKgAgudo} onChange={v=>set("kcalKgAgudo",v)} step="0.5"/>
            <NUM label="Ptn/kg" val={d.ptnKgAgudo} onChange={v=>set("ptnKgAgudo",v)} step="0.1"/>
          </div>
          <div className="grid2">
            <Res label="Kcal/dia" val={c.kcalAgudo} unit="kcal"/>
            <Res label="Proteína/dia" val={c.ptnAgudo} unit="g"/>
          </div>
          <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"8px 0 0"}}>BRASPEN 2023: 15-20 kcal/kg | 1,2 g ptn/kg</p>
        </div>
        <div style={{background:"rgba(255,255,255,0.03)",borderRadius:14,padding:16,border:"1px solid rgba(255,255,255,0.07)"}}>
          <div style={{color:"#6ee7b7",fontWeight:700,fontSize:13,marginBottom:12}}>🔄 Fase Recuperação (>4° dia)</div>
          <div className="grid2" style={{marginBottom:10}}>
            <NUM label="Kcal/kg" val={d.kcalKgRecup} onChange={v=>set("kcalKgRecup",v)} step="0.5"/>
            <NUM label="Ptn/kg" val={d.ptnKgRecup} onChange={v=>set("ptnKgRecup",v)} step="0.1"/>
          </div>
          <div className="grid2">
            <Res label="Kcal/dia" val={c.kcalRecup} unit="kcal"/>
            <Res label="Proteína/dia" val={c.ptnRecup} unit="g"/>
          </div>
          <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"8px 0 0"}}>BRASPEN 2023: 25-30 kcal/kg | 1,3-2,0 g ptn/kg</p>
        </div>
      </div>
    </div>
  );
}
