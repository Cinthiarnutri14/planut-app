// src/components/TabEvolucao.js
export default function TabEvolucao({dados:d,set,calc:c}) {
  const dias = d.evolucao;
  const setDia = (i,k,v) => {
    const novo = dias.map((dia,idx)=>idx===i?{...dia,[k]:v}:dia);
    set("evolucao",novo);
  };
  const campos = [
    {key:"data",label:"Data",type:"text",placeholder:"DD/MM"},
    {key:"peso",label:"Peso (kg)",type:"number"},
    {key:"glicemia",label:"Glicemia",type:"number"},
    {key:"kcal",label:"Kcal ofert.",type:"number"},
    {key:"ptn",label:"Ptn (g)",type:"number"},
    {key:"vrg",label:"VRG (ml)",type:"number"},
    {key:"bh",label:"BH (ml)",type:"number"},
    {key:"via",label:"Via TN",type:"text"},
    {key:"albumina",label:"Albumina",type:"number"},
  ];
  const media_kcal = dias.filter(d=>d.kcal).length ?
    (dias.reduce((a,d)=>a+(Number(d.kcal)||0),0)/dias.filter(d=>d.kcal).length).toFixed(0) : "—";
  const media_ptn = dias.filter(d=>d.ptn).length ?
    (dias.reduce((a,d)=>a+(Number(d.ptn)||0),0)/dias.filter(d=>d.ptn).length).toFixed(1) : "—";

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>📊</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Evolução Nutricional</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>Monitoramento diário · Reavaliação 7-10 dias · BRASPEN 2023</p>
        </div>
      </div>

      <div className="grid3" style={{marginBottom:20}}>
        <div style={{background:"rgba(77,184,255,0.08)",border:"1px solid rgba(77,184,255,0.2)",borderRadius:12,padding:14}}>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:4}}>META CALÓRICA</div>
          <div style={{color:"#4db8ff",fontWeight:800,fontSize:22}}>{c.kcalAgudo||"—"} <span style={{fontSize:13,fontWeight:400}}>kcal/dia</span></div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>Média atual: {media_kcal} kcal</div>
        </div>
        <div style={{background:"rgba(16,185,129,0.08)",border:"1px solid rgba(16,185,129,0.2)",borderRadius:12,padding:14}}>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:4}}>META PROTEICA</div>
          <div style={{color:"#6ee7b7",fontWeight:800,fontSize:22}}>{c.ptnAgudo||"—"} <span style={{fontSize:13,fontWeight:400}}>g/dia</span></div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>Média atual: {media_ptn} g</div>
        </div>
        <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,padding:14}}>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:4}}>PESO ESTIMADO</div>
          <div style={{color:"#fff",fontWeight:800,fontSize:22}}>{c.peso||"—"} <span style={{fontSize:13,fontWeight:400}}>kg</span></div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>IMC: {c.imc||"—"} kg/m²</div>
        </div>
      </div>

      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",minWidth:700}}>
          <thead>
            <tr>
              <th style={{background:"rgba(26,86,219,0.3)",color:"#fff",padding:"10px 12px",fontSize:11,
                textAlign:"left",fontWeight:700,letterSpacing:0.5,borderRadius:"8px 0 0 0",whiteSpace:"nowrap"}}>
                Parâmetro
              </th>
              {dias.map((_,i)=>(
                <th key={i} style={{background:"rgba(26,86,219,0.3)",color:"#4db8ff",padding:"10px 8px",
                  fontSize:11,textAlign:"center",fontWeight:700,minWidth:90}}>Dia {i+1}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {campos.map(campo=>(
              <tr key={campo.key}>
                <td style={{background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.7)",
                  padding:"8px 12px",fontSize:12,fontWeight:600,whiteSpace:"nowrap",
                  borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
                  {campo.label}
                </td>
                {dias.map((dia,i)=>(
                  <td key={i} style={{padding:"4px 6px",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
                    <input type={campo.type} value={dia[campo.key]} placeholder={campo.placeholder||""}
                      onChange={e=>setDia(i,campo.key,e.target.value)}
                      style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",
                        color:"#fff",borderRadius:6,padding:"6px 8px",fontSize:12,width:"100%",
                        boxSizing:"border-box",textAlign:"center"}}/>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{marginTop:16,background:"rgba(251,191,36,0.08)",border:"1px solid rgba(251,191,36,0.2)",borderRadius:12,padding:14}}>
        <p style={{color:"#fcd34d",fontSize:12,margin:0,lineHeight:1.7}}>
          ⚠️ Meta: adequação ≥80% de energia e proteína · Evitar jejum {">"}24h · Monitorar síndrome de realimentação (↓P, K, Mg) · Glicemia 140-180 mg/dL
        </p>
      </div>
    </div>
  );
}
