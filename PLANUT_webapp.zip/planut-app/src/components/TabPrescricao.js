// src/components/TabPrescricao.js
const TXT=({label,val,onChange,placeholder,rows})=>(<div><label>{label}</label>{rows?<textarea rows={rows} value={val} onChange={e=>onChange(e.target.value)} placeholder={placeholder} style={{resize:"vertical"}}/>:<input type="text" value={val} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/>}</div>);

function InfoRow({label,val,highlight}) {
  return (
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
      padding:"10px 14px",background:highlight?"rgba(77,184,255,0.08)":"rgba(255,255,255,0.03)",
      borderRadius:8,border:`1px solid ${highlight?"rgba(77,184,255,0.2)":"rgba(255,255,255,0.06)"}`}}>
      <span style={{color:"rgba(255,255,255,0.5)",fontSize:12}}>{label}</span>
      <span style={{color:highlight?"#4db8ff":"#fff",fontWeight:highlight?700:500,fontSize:13}}>{val||"—"}</span>
    </div>
  );
}

export default function TabPrescricao({dados:d,set,calc:c}) {
  const handlePrint = () => window.print();
  const today = new Date().toLocaleDateString("pt-BR");

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:28}}>🏥</span>
          <div>
            <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Prescrição Nutricional</h2>
            <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>Consolidado automático · PLANUT</p>
          </div>
        </div>
        <button onClick={handlePrint} className="no-print" style={{
          background:"linear-gradient(135deg,#1a56db,#0e3a8a)",color:"#fff",
          border:"none",borderRadius:10,padding:"10px 20px",cursor:"pointer",
          fontSize:13,fontWeight:700,boxShadow:"0 4px 16px rgba(26,86,219,0.4)"
        }}>🖨️ Imprimir / PDF</button>
      </div>

      <div style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:24}}>
        {/* Identificação */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,paddingBottom:16,borderBottom:"1px solid rgba(255,255,255,0.07)"}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:48,height:48,borderRadius:12,background:"linear-gradient(135deg,#1a56db,#4db8ff)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22}}>🏥</div>
            <div>
              <div style={{color:"#fff",fontWeight:800,fontSize:18}}>PLANUT</div>
              <div style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>Planejamento Nutricional Hospitalar · UTI</div>
            </div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{color:"rgba(255,255,255,0.6)",fontSize:13}}>Data: <strong style={{color:"#fff"}}>{today}</strong></div>
            <div style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>planuthospitalar@gmail.com</div>
          </div>
        </div>

        {/* Campos manuais */}
        <div className="grid2" style={{marginBottom:20}}>
          <TXT label="Nome do Paciente" val={d.paciente} onChange={v=>set("paciente",v)} placeholder="Nome completo"/>
          <TXT label="CRN / Nutricionista" val={d.cro} onChange={v=>set("cro",v)} placeholder="CRN-X 00000"/>
        </div>

        {/* Dados automáticos */}
        <div className="section-title">Identificação Automática</div>
        <div className="grid3" style={{gap:8,marginBottom:16}}>
          <InfoRow label="Sexo" val={d.sexo}/>
          <InfoRow label="Idade" val={`${d.idade} anos`}/>
          <InfoRow label="Cor/Raça" val={d.raca}/>
        </div>

        <div className="section-title">Antropometria</div>
        <div className="grid3" style={{gap:8,marginBottom:16}}>
          <InfoRow label="Peso Est." val={`${c.peso||"—"} kg`} highlight/>
          <InfoRow label="Altura Est." val={`${c.alt||"—"} m`} highlight/>
          <InfoRow label="IMC" val={`${c.imc||"—"} kg/m²`} highlight/>
          <InfoRow label="CB" val={`${d.cb||"—"} cm`}/>
          <InfoRow label="CP" val={`${d.cp||"—"} cm`}/>
          <InfoRow label="Classif. CP" val={c.classCP}/>
          <InfoRow label="Peso Ideal Adulto" val={`${c.piAdulto||"—"} kg`}/>
          <InfoRow label="Peso Ideal Idoso" val={`${c.piIdoso||"—"} kg`}/>
        </div>

        <div className="section-title">Triagem e Diagnóstico</div>
        <div className="grid2" style={{gap:8,marginBottom:16}}>
          <InfoRow label="NUTRIC Score" val={c.nutric_total!==""?`${c.nutric_total} pts – ${c.nutric_total>=5?"Alto risco":"Baixo risco"}`:"—"} highlight/>
          <InfoRow label="NRS-2002" val={`${c.nrs_total} pts – ${c.nrs_total>=3?"Risco nutricional":c.nrs_total>=1?"Risco moderado":"Sem risco"}`} highlight/>
          <InfoRow label="Diagnóstico GLIM" val={c.glim_dx} highlight/>
        </div>

        <div className="section-title">Necessidade Calórico-Proteica</div>
        <div className="grid4" style={{gap:8,marginBottom:16}}>
          <InfoRow label="Kcal/dia (agudo)" val={`${c.kcalAgudo||"—"} kcal`} highlight/>
          <InfoRow label="Ptn/dia (agudo)" val={`${c.ptnAgudo||"—"} g`} highlight/>
          <InfoRow label="Kcal/dia (recup.)" val={`${c.kcalRecup||"—"} kcal`}/>
          <InfoRow label="Ptn/dia (recup.)" val={`${c.ptnRecup||"—"} g`}/>
        </div>

        <div className="section-title">Plano Terapêutico</div>
        <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:20}}>
          <InfoRow label="Via de TN" val={d.sonda} highlight/>
          <TXT label="Fórmula / Solução prescrita" val={d.formula_prescrita} onChange={v=>set("formula_prescrita",v)} placeholder="Nome da fórmula, concentração..."/>
          <div className="grid2">
            <TXT label="Volume total/dia (ml)" val={d.vol_dia} onChange={v=>set("vol_dia",v)} placeholder="ml/dia"/>
            <TXT label="Velocidade (ml/h)" val={d.vel_hora} onChange={v=>set("vel_hora",v)} placeholder="ml/h"/>
          </div>
          <TXT label="Observações clínicas" val={d.obs} onChange={v=>set("obs",v)} placeholder="Condutas, intercorrências, ajustes..." rows={3}/>
        </div>

        {/* Assinatura */}
        <div style={{borderTop:"1px solid rgba(255,255,255,0.07)",paddingTop:20,display:"flex",justifyContent:"center"}}>
          <div style={{textAlign:"center",minWidth:200}}>
            <div style={{borderBottom:"1px solid rgba(255,255,255,0.2)",paddingBottom:8,marginBottom:8,width:220,margin:"0 auto 8px"}}/>
            <div style={{color:"#fff",fontWeight:700,fontSize:15}}>Gabriele</div>
            <div style={{color:"rgba(255,255,255,0.4)",fontSize:12}}>Nutricionista{d.cro?` – CRN: ${d.cro}`:""}</div>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:4}}>{today}</div>
          </div>
        </div>
      </div>

      <div style={{marginTop:16,background:"rgba(77,184,255,0.06)",border:"1px solid rgba(77,184,255,0.15)",borderRadius:12,padding:14}} className="no-print">
        <p style={{color:"rgba(255,255,255,0.4)",fontSize:12,margin:0}}>
          💡 Clique em <strong style={{color:"#4db8ff"}}>Imprimir / PDF</strong> para salvar ou imprimir a prescrição · Os dados são preenchidos automaticamente das outras abas
        </p>
      </div>
    </div>
  );
}
