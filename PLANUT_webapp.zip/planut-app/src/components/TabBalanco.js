// src/components/TabBalanco.js
const ganhoLabels = [
  {key:"enteral",label:"Dieta Enteral (ml)"},
  {key:"parenteral",label:"Dieta Parenteral / NP (ml)"},
  {key:"sf",label:"SF 0,9% / Soro (ml)"},
  {key:"sg",label:"SG 5% / 10% (ml)"},
  {key:"ringer",label:"Ringer Lactato (ml)"},
  {key:"albumina_hemo",label:"Albumina / Hemocomponentes (ml)"},
  {key:"medicamentos",label:"Medicamentos EV (ml)"},
  {key:"vo",label:"Água / VO / SNE (ml)"},
  {key:"outros",label:"Outros (ml)"},
];
const perdaLabels = [
  {key:"diurese",label:"Diurese (ml)"},
  {key:"drenos",label:"Drenos (ml)"},
  {key:"sng",label:"Débito Nasogástrico / SNE (ml)"},
  {key:"fezes",label:"Fezes / Diarreia (ml)"},
  {key:"vomitos",label:"Vômitos (ml)"},
  {key:"sangramento",label:"Sangramento estimado (ml)"},
  {key:"outros_p",label:"Outros (ml)"},
];
const turnos = ["6h","12h","18h","24h"];

function sumArr(arr) { return arr.reduce((a,v)=>a+(Number(v)||0),0); }

export default function TabBalanco({dados:d,set,calc:c}) {
  const ganhos = d.ganhos; const perdas = d.perdas;
  const peso = Number(c.peso)||0;

  const setGanho = (k,i,v) => {
    const arr = [...(ganhos[k]||["","","",""])]; arr[i]=v;
    set("ganhos",{...ganhos,[k]:arr});
  };
  const setPerda = (k,i,v) => {
    const arr = [...(perdas[k]||["","","",""])]; arr[i]=v;
    set("perdas",{...perdas,[k]:arr});
  };

  const totalGanhosTurnos = turnos.map((_,ti)=>ganhoLabels.reduce((a,{key})=>a+(Number(ganhos[key]?.[ti])||0),0));
  const totalPorTurno = turnos.map((_,ti)=>perdaLabels.reduce((a,{key})=>a+(Number(perdas[key]?.[ti])||0),0));
  const perdaInsens = peso>0 ? peso*8 : 0;
  const totalGanho24 = totalGanhosTurnos.reduce((a,v)=>a+v,0);
  const totalPerda24 = totalPorTurno.reduce((a,v)=>a+v,0) + perdaInsens;
  const balanco = totalGanho24 - totalPerda24;
  const diurese24 = perdas.diurese ? sumArr(perdas.diurese) : 0;
  const diureseHoraria = peso>0 ? (diurese24/(peso*24)).toFixed(2) : 0;

  const balancoColor = Math.abs(balanco)<=500?"#10b981":balanco>500?"#ef4444":"#fbbf24";

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>💧</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Balanço Hídrico</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>Registro por turno · Meta: -500 a +500 ml/dia · BRASPEN 2023</p>
        </div>
      </div>

      {/* Cards resumo */}
      <div className="grid4" style={{marginBottom:20}}>
        {[
          {label:"Total Ganhos",val:`${totalGanho24.toFixed(0)} ml`,color:"rgba(16,185,129,0.1)",border:"rgba(16,185,129,0.2)",tc:"#6ee7b7"},
          {label:"Total Perdas",val:`${totalPerda24.toFixed(0)} ml`,color:"rgba(239,68,68,0.1)",border:"rgba(239,68,68,0.2)",tc:"#fca5a5"},
          {label:"Balanço 24h",val:`${balanco>0?"+":""}${balanco.toFixed(0)} ml`,color:`rgba(${Math.abs(balanco)<=500?"16,185,129":balanco>500?"239,68,68":"251,191,36"},0.1)`,border:`rgba(${Math.abs(balanco)<=500?"16,185,129":balanco>500?"239,68,68":"251,191,36"},0.2)`,tc:balancoColor},
          {label:"Diurese horária",val:`${diureseHoraria} ml/kg/h`,color:Number(diureseHoraria)>=0.5?"rgba(16,185,129,0.1)":"rgba(239,68,68,0.1)",border:Number(diureseHoraria)>=0.5?"rgba(16,185,129,0.2)":"rgba(239,68,68,0.2)",tc:Number(diureseHoraria)>=0.5?"#6ee7b7":"#fca5a5"},
        ].map((card,i)=>(
          <div key={i} style={{background:card.color,border:`1px solid ${card.border}`,borderRadius:12,padding:14}}>
            <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:4}}>{card.label}</div>
            <div style={{color:card.tc,fontWeight:800,fontSize:18}}>{card.val}</div>
          </div>
        ))}
      </div>

      {/* Tabela Ganhos */}
      <div className="section-title">📥 Ganhos (Entradas)</div>
      <div style={{overflowX:"auto",marginBottom:16}}>
        <table style={{width:"100%",borderCollapse:"collapse",minWidth:550}}>
          <thead>
            <tr>
              <th style={{background:"rgba(16,185,129,0.2)",color:"#6ee7b7",padding:"8px 12px",fontSize:11,textAlign:"left",fontWeight:700,minWidth:160}}>Fonte</th>
              {turnos.map(t=><th key={t} style={{background:"rgba(16,185,129,0.2)",color:"#6ee7b7",padding:"8px",fontSize:11,textAlign:"center",fontWeight:700}}>{t}</th>)}
              <th style={{background:"rgba(16,185,129,0.3)",color:"#6ee7b7",padding:"8px",fontSize:11,textAlign:"center",fontWeight:700}}>Total</th>
            </tr>
          </thead>
          <tbody>
            {ganhoLabels.map(({key,label})=>{
              const arr = ganhos[key]||["","","",""];
              const tot = sumArr(arr);
              return (
                <tr key={key}>
                  <td style={{background:"rgba(255,255,255,0.03)",color:"rgba(255,255,255,0.6)",padding:"6px 12px",fontSize:12,borderBottom:"1px solid rgba(255,255,255,0.04)"}}>{label}</td>
                  {arr.map((v,i)=>(
                    <td key={i} style={{padding:"4px 6px",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                      <input type="number" min="0" value={v} onChange={e=>setGanho(key,i,e.target.value)}
                        style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",color:"#fff",borderRadius:6,padding:"6px 8px",fontSize:12,width:"100%",boxSizing:"border-box",textAlign:"center"}}/>
                    </td>
                  ))}
                  <td style={{background:"rgba(16,185,129,0.08)",color:"#6ee7b7",fontWeight:700,textAlign:"center",fontSize:13,padding:"6px 8px"}}>{tot}</td>
                </tr>
              );
            })}
            <tr>
              <td style={{background:"rgba(16,185,129,0.15)",color:"#6ee7b7",padding:"8px 12px",fontWeight:700,fontSize:13}}>✅ TOTAL GANHOS</td>
              {totalGanhosTurnos.map((v,i)=><td key={i} style={{background:"rgba(16,185,129,0.15)",color:"#6ee7b7",fontWeight:700,textAlign:"center",padding:"8px"}}>{v}</td>)}
              <td style={{background:"rgba(16,185,129,0.25)",color:"#6ee7b7",fontWeight:800,textAlign:"center",fontSize:15,padding:"8px"}}>{totalGanho24}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Tabela Perdas */}
      <div className="section-title">📤 Perdas (Saídas)</div>
      <div style={{overflowX:"auto",marginBottom:16}}>
        <table style={{width:"100%",borderCollapse:"collapse",minWidth:550}}>
          <thead>
            <tr>
              <th style={{background:"rgba(26,86,219,0.3)",color:"#4db8ff",padding:"8px 12px",fontSize:11,textAlign:"left",fontWeight:700,minWidth:160}}>Fonte</th>
              {turnos.map(t=><th key={t} style={{background:"rgba(26,86,219,0.3)",color:"#4db8ff",padding:"8px",fontSize:11,textAlign:"center",fontWeight:700}}>{t}</th>)}
              <th style={{background:"rgba(26,86,219,0.4)",color:"#4db8ff",padding:"8px",fontSize:11,textAlign:"center",fontWeight:700}}>Total</th>
            </tr>
          </thead>
          <tbody>
            {perdaLabels.map(({key,label})=>{
              const arr = perdas[key]||["","","",""];
              const tot = sumArr(arr);
              return (
                <tr key={key}>
                  <td style={{background:"rgba(255,255,255,0.03)",color:"rgba(255,255,255,0.6)",padding:"6px 12px",fontSize:12,borderBottom:"1px solid rgba(255,255,255,0.04)"}}>{label}</td>
                  {arr.map((v,i)=>(
                    <td key={i} style={{padding:"4px 6px",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                      <input type="number" min="0" value={v} onChange={e=>setPerda(key,i,e.target.value)}
                        style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",color:"#fff",borderRadius:6,padding:"6px 8px",fontSize:12,width:"100%",boxSizing:"border-box",textAlign:"center"}}/>
                    </td>
                  ))}
                  <td style={{background:"rgba(26,86,219,0.1)",color:"#4db8ff",fontWeight:700,textAlign:"center",fontSize:13,padding:"6px 8px"}}>{tot}</td>
                </tr>
              );
            })}
            <tr>
              <td style={{background:"rgba(255,165,0,0.15)",color:"#fcd34d",padding:"8px 12px",fontWeight:700,fontSize:12}}>Perdas insensíveis (~8ml/kg/dia)</td>
              <td colSpan={4} style={{background:"rgba(255,165,0,0.08)",color:"#fcd34d",textAlign:"center",fontSize:12,padding:"8px"}}>Estimativa automática: {perdaInsens.toFixed(0)} ml</td>
              <td style={{background:"rgba(255,165,0,0.15)",color:"#fcd34d",fontWeight:700,textAlign:"center",padding:"8px"}}>{perdaInsens.toFixed(0)}</td>
            </tr>
            <tr>
              <td style={{background:"rgba(26,86,219,0.2)",color:"#4db8ff",padding:"8px 12px",fontWeight:700,fontSize:13}}>✅ TOTAL PERDAS</td>
              {totalPorTurno.map((v,i)=><td key={i} style={{background:"rgba(26,86,219,0.2)",color:"#4db8ff",fontWeight:700,textAlign:"center",padding:"8px"}}>{v}</td>)}
              <td style={{background:"rgba(26,86,219,0.3)",color:"#4db8ff",fontWeight:800,textAlign:"center",fontSize:15,padding:"8px"}}>{totalPerda24.toFixed(0)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style={{background:`rgba(${Math.abs(balanco)<=500?"16,185,129":balanco>500?"239,68,68":"251,191,36"},0.1)`,
        border:`1px solid rgba(${Math.abs(balanco)<=500?"16,185,129":balanco>500?"239,68,68":"251,191,36"},0.25)`,
        borderRadius:14,padding:20,textAlign:"center"}}>
        <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,marginBottom:4}}>BALANÇO HÍDRICO 24h</div>
        <div style={{color:balancoColor,fontWeight:900,fontSize:32}}>{balanco>0?"+":""}{balanco.toFixed(0)} ml</div>
        <div style={{color:balancoColor,fontSize:14,fontWeight:600,marginTop:4}}>
          {Math.abs(balanco)<=500?"✅ Balanço adequado":balanco>500?"🔴 Balanço positivo elevado – risco de sobrecarga":"🟡 Balanço negativo – avaliar hidratação"}
        </div>
      </div>
    </div>
  );
}
