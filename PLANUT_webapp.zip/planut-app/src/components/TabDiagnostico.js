// src/components/TabDiagnostico.js
const SEL=({label,val,onChange,opts})=>(<div><label>{label}</label><select value={val} onChange={e=>onChange(e.target.value)}>{opts.map(o=><option key={o}>{o}</option>)}</select></div>);
const NUM=({label,val,onChange,step,unit})=>(<div><label>{label}{unit&&<span style={{color:"rgba(255,255,255,0.3)",marginLeft:4,fontWeight:400,textTransform:"none"}}>{unit}</span>}</label><input type="number" min="0" step={step||0.1} value={val} onChange={e=>onChange(e.target.value)}/></div>);
const TXT=({label,val,onChange,placeholder})=>(<div><label>{label}</label><textarea rows={2} value={val} onChange={e=>onChange(e.target.value)} placeholder={placeholder} style={{resize:"vertical"}}/></div>);

export default function TabDiagnostico({dados:d,set,calc:c}) {
  const dx = c.glim_dx;
  const isDesnutrido = dx.includes("DESNUTRIÇÃO");
  const isGrave = dx.includes("GRAVE");

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>📋</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Diagnóstico Nutricional</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>Critérios GLIM · Cederholm et al. 2019 · BRASPEN 2023</p>
        </div>
      </div>

      <div style={{background:"rgba(77,184,255,0.06)",borderRadius:12,padding:14,marginBottom:20,border:"1px solid rgba(77,184,255,0.15)"}}>
        <p style={{color:"rgba(255,255,255,0.5)",fontSize:12,margin:0}}>
          📌 Para diagnóstico: mínimo <strong style={{color:"#4db8ff"}}>1 critério fenotípico + 1 critério etiológico</strong> · Reavaliação a cada 7-10 dias (BRASPEN 2023)
        </p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
        <div>
          <div className="section-title">Critérios Fenotípicos</div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <NUM label="Perda de peso não intencional (%)" val={d.perdaPeso} onChange={v=>set("perdaPeso",v)} step="0.5"/>
            <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"-6px 0 0"}}>Moderado: 5-10% em 6m ou 10-20% em mais de 6m | Grave: >10% em 6m</p>
            <div style={{background:"rgba(255,255,255,0.03)",borderRadius:10,padding:12,border:"1px solid rgba(255,255,255,0.07)"}}>
              <label>IMC (calculado)</label>
              <div style={{color:"#4db8ff",fontWeight:700,fontSize:16}}>{c.imc||"—"} kg/m²</div>
              <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"4px 0 0"}}>{"<70a: Mod <20 | Grave <18,5 | ≥70a: Mod <22 | Grave <20"}</p>
            </div>
            <SEL label="Redução de Massa Muscular" val={d.glim_massa} onChange={v=>set("glim_massa",v)} opts={["Ausente","Leve/Moderada","Grave"]}/>
            <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"-6px 0 0"}}>CP / CMB / BIA / DEXA – avaliação clínica</p>
          </div>
        </div>
        <div>
          <div className="section-title">Critérios Etiológicos</div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <SEL label="Redução de ingestão / absorção alimentar?" val={d.red_ingestao_glim} onChange={v=>set("red_ingestao_glim",v)} opts={["Não","Sim"]}/>
            <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"-6px 0 0"}}>{"Ingestão ≤50% das necessidades por >1 semana OU distúrbio absortivo"}</p>
            <SEL label="Doença / Inflamação aguda ou crônica?" val={d.doenca_inflam} onChange={v=>set("doenca_inflam",v)} opts={["Sim","Não"]}/>
            <p style={{color:"rgba(255,255,255,0.3)",fontSize:11,margin:"-6px 0 0"}}>Doença aguda grave (UTI), doença crônica, neoplasia, cirurgia major</p>
            <TXT label="Etiologia / Diagnóstico principal" val={d.etiologia} onChange={v=>set("etiologia",v)} placeholder="Ex: Doença aguda grave com inflamação sistêmica"/>
          </div>
        </div>
      </div>

      <div style={{marginTop:20}}>
        <div className="section-title">Resultado GLIM</div>
        <div style={{
          background:isGrave?"rgba(239,68,68,0.12)":isDesnutrido?"rgba(251,191,36,0.1)":"rgba(16,185,129,0.1)",
          border:`1px solid ${isGrave?"rgba(239,68,68,0.3)":isDesnutrido?"rgba(251,191,36,0.3)":"rgba(16,185,129,0.3)"}`,
          borderRadius:14, padding:20
        }}>
          <div style={{fontSize:22,marginBottom:8}}>{isGrave?"🔴":isDesnutrido?"🟡":"🟢"}</div>
          <div style={{color:isGrave?"#fca5a5":isDesnutrido?"#fcd34d":"#6ee7b7",fontWeight:800,fontSize:18,marginBottom:4}}>{dx}</div>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:12}}>
            {c.fenot_grave||c.fenot_mod?"Critérios fenotípicos presentes · ":"Nenhum critério fenotípico suficiente · "}
            {c.etiol_pos?"Critérios etiológicos presentes":"Critérios etiológicos ausentes"}
          </div>
        </div>
      </div>
    </div>
  );
}
