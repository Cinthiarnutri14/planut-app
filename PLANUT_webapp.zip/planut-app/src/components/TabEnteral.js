// src/components/TabEnteral.js
const SEL=({label,val,onChange,opts})=>(<div><label>{label}</label><select value={val} onChange={e=>onChange(e.target.value)}>{opts.map(o=><option key={o}>{o}</option>)}</select></div>);
const NUM=({label,val,onChange,step,unit})=>(<div><label>{label}{unit&&<span style={{color:"rgba(255,255,255,0.3)",marginLeft:4,fontWeight:400,textTransform:"none"}}>{unit}</span>}</label><input type="number" min="0" step={step||1} value={val} onChange={e=>onChange(e.target.value)}/></div>);
const TXT=({label,val,onChange,placeholder})=>(<div><label>{label}</label><input type="text" value={val} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/></div>);

function AdeqBar({label,val,meta}) {
  const pct = val&&meta ? Math.min(+(val/meta*100).toFixed(0),150) : 0;
  const color = pct>=80?"#10b981":pct>=60?"#fbbf24":"#ef4444";
  return (
    <div style={{background:"rgba(255,255,255,0.03)",borderRadius:12,padding:14,border:"1px solid rgba(255,255,255,0.07)"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
        <span style={{color:"rgba(255,255,255,0.6)",fontSize:12}}>{label}</span>
        <span style={{color,fontWeight:700,fontSize:14}}>{val||"—"} / {meta||"—"}</span>
      </div>
      <div style={{height:8,background:"rgba(255,255,255,0.06)",borderRadius:4}}>
        <div style={{height:"100%",width:`${pct}%`,background:color,borderRadius:4,transition:"width 0.4s"}}/>
      </div>
      <div style={{color:color,fontSize:11,marginTop:4,fontWeight:600}}>
        {pct>=80?"✅ Adequado ≥80%":pct>=60?"🟡 Parcial 60-79%":val?"🔴 Insuficiente <60%":""}
      </div>
    </div>
  );
}

export default function TabEnteral({dados:d,set,calc:c}) {
  const setG = (k,v) => set(k,v);
  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontSize:28}}>🍼</span>
        <div>
          <h2 style={{margin:0,color:"#fff",fontSize:20,fontWeight:800}}>Terapia Nutricional Enteral</h2>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:13}}>TNE · BRASPEN 2023 · Início: 24-48h após admissão</p>
        </div>
      </div>

      <div className="grid2">
        <div>
          <div className="section-title">Via de Acesso</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SEL label="Sonda / Via" val={d.sonda} onChange={v=>setG("sonda",v)} opts={["Nasogástrica","Nasoenteral/Pós-pilórica","Gastrostomia","Jejunostomia"]}/>
            <SEL label="Posição da sonda" val={d.posicao_sonda} onChange={v=>setG("posicao_sonda",v)} opts={["Gástrico","Pós-pilórico (Jejunal)","Duodenal"]}/>
            <TXT label="Indicação da TNE" val={d.indicacao_tne} onChange={v=>setG("indicacao_tne",v)}/>
            <TXT label="Data início TNE" val={d.data_tne} onChange={v=>setG("data_tne",v)} placeholder="DD/MM/AAAA"/>
            <SEL label="Tolerância TGI" val={d.tolerancia_tgi} onChange={v=>setG("tolerancia_tgi",v)} opts={["Boa","Regular – Intolerância parcial","Ruim – Intolerância grave","Suspensa"]}/>
          </div>
        </div>
        <div>
          <div className="section-title">Fórmula Enteral</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <TXT label="Fórmula prescrita" val={d.formula} onChange={v=>setG("formula",v)}/>
            <SEL label="Fibras" val={d.fibras} onChange={v=>setG("fibras",v)} opts={["Com fibras","Sem fibras","Oligomérica","Semielemental","Polimérica"]}/>
            <NUM label="Densidade calórica" val={d.densidade} onChange={v=>setG("densidade",v)} step="0.1" unit="kcal/ml"/>
            <NUM label="Proteína da fórmula" val={d.ptn_formula} onChange={v=>setG("ptn_formula",v)} step="1" unit="g/L"/>
            <TXT label="Módulo adicional" val={d.modulo} onChange={v=>setG("modulo",v)}/>
          </div>
        </div>
      </div>

      <div className="section-title">Volumes e Adequação</div>
      <div className="grid3">
        <NUM label="Volume prescrito" val={d.vol_prescrito} onChange={v=>setG("vol_prescrito",v)} unit="ml/dia"/>
        <NUM label="Volume infundido" val={d.vol_infundido} onChange={v=>setG("vol_infundido",v)} unit="ml/dia"/>
        <div style={{background:"rgba(255,255,255,0.03)",borderRadius:10,padding:12,border:"1px solid rgba(255,255,255,0.07)"}}>
          <label>Meta calórica</label>
          <div style={{color:"#4db8ff",fontWeight:700,fontSize:16}}>{c.kcalAgudo||"—"} <span style={{fontSize:12,fontWeight:400}}>kcal/dia</span></div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>Meta proteica: {c.ptnAgudo||"—"} g/dia</div>
        </div>
      </div>
      <div className="grid3" style={{marginTop:12}}>
        <AdeqBar label="Energia (kcal)" val={c.kcal_ofert} meta={c.kcalAgudo}/>
        <AdeqBar label="Proteína (g)" val={c.ptn_ofert} meta={c.ptnAgudo}/>
        <AdeqBar label="Volume (ml)" val={d.vol_infundido} meta={d.vol_prescrito}/>
      </div>

      <div className="section-title">Monitoramento</div>
      <div className="grid3">
        <NUM label="VRG – Vol. Residual Gástrico" val={d.vrg} onChange={v=>setG("vrg",v)} unit="ml"/>
        <div style={{background:Number(d.vrg)>0?(Number(d.vrg)<500?"rgba(16,185,129,0.1)":"rgba(239,68,68,0.1)"):"rgba(255,255,255,0.03)",
          borderRadius:10,padding:12,border:"1px solid rgba(255,255,255,0.07)"}}>
          <label>Conduta VRG</label>
          <div style={{color:Number(d.vrg)>=500?"#fca5a5":"#6ee7b7",fontWeight:700,fontSize:13}}>
            {d.vrg===""?"—":Number(d.vrg)<500?"✅ Manter TNE":"⚠️ Avaliar redução/suspensão"}
          </div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:11,marginTop:2}}>Meta: VRG {"<"}500 ml</div>
        </div>
        <SEL label="Procinético em uso?" val={d.proicinetico} onChange={v=>setG("proicinetico",v)} opts={["Não","Sim – Eritromicina IV","Sim – Metoclopramida","Sim – Combinado"]}/>
      </div>

      <div style={{marginTop:16,background:"rgba(251,191,36,0.08)",border:"1px solid rgba(251,191,36,0.2)",borderRadius:12,padding:14}}>
        <p style={{color:"#fcd34d",fontSize:12,margin:0,lineHeight:1.7}}>
          ⚠️ <strong>BRASPEN 2023:</strong> VRG {"<"}500ml → manter TNE · Cabeceira 30-45° · Eritromicina IV como 1ª linha procinética · NPS somente após 7-10 dias se {"<"}60% da meta · Suspender TNE em instabilidade hemodinâmica
        </p>
      </div>
    </div>
  );
}
